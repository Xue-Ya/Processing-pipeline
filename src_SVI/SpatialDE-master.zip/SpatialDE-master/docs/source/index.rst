.. SpatialDE documentation master file, created by
   sphinx-quickstart on Fri Oct  9 11:58:49 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SpatialDE's documentation!
=====================================
.. toctree::
   :maxdepth: 10
   :caption: Table of Contents
   :name: mastertoc

API reference
=============
.. autosummary::
   :caption: API reference
   :toctree: generated
   :template: module.rst

   SpatialDE
..
.. .. automodule:: SpatialDE
..    :members:
..    :undoc-members:
..    :imported-members:
..


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
