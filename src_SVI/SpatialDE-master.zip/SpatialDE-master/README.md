# SpatialDE 2

[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Docs: latest](https://img.shields.io/badge/docs-latest-blue.svg)](https://pmbio.github.io/SpatialDE)

This is the next iteration of the SpatialDE package for analyzing spatial transcriptomics data.
